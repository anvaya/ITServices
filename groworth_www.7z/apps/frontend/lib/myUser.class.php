<?php

class myUser extends sfGuardSecurityUser //sfBasicSecurityUser
{
}
