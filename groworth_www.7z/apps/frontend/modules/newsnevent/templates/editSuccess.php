<h1>Edit Newsnevent</h1>

<?php include_partial('form', array('form' => $form)) ?>
