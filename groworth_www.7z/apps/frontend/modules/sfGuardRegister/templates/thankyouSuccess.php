<?php use_helper('I18N') ?>
<div id="main_content" style="width: 960px;">
<h1><?php echo __('Thank you !', null, 'sf_guard') ?></h1>

  <p style="font-size: 2em; color: #2E444F;line-height: 1em;"> Thank you for registering with us. You can now log in to your Members Area.</p>  
  <p><?php echo link_to('Go To Home Page','@homepage'); ?></p>
  <div style="clear:both;"></div>
</div>