<?php /* @var $user sfGuardUser */ ?>
A new user has signed up as a member on Groworth.in

Name:  <?php echo $user->getFirstName() . " " . $user->getLastName(); ?>

Email Address: <?php echo $user->getEmailAddress(); ?>

Groworth.in


