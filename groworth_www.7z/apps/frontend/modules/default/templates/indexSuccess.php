<div class="wrapper1" style="text-align: center">
                    <?php echo image_tag("tax01.png",array("style"=>"height: 500px;","alt"=>"NRI Tax Services"));?>                        
		</div>

		<div class="wrapper1" style="min-height: 180px; display: none;">
			<div class="row-fluid">
				<!--
				<div class="span4 span4-color1" style="height: 336px">
					<img src="images/travel.jpg" width="271px" border="0" />
					<h4>Tours and Travel</h4>
					<p>Coming Soon...</p>
					<p><a href="#" class="white-btn read-more">Coming Soon...</a></p>
				</div>

				<div class="span4 span4-color2" style="height: 336px">
					<img src="images/pm.jpg" width="271px" height="180px" border="0" style="border-bottom: 1px solid #eee" />
					<h4>Property Management</h4>
					<p>Coming Soon...</p>
					<p><a href="#" class="white-btn read-more">Coming Soon...</a></p>
				</div>
				
				<div class="span4" style="height:150px;">
					<h4 style="color:#426DAD;">Connect with us!</h4>
					<p>Follow us to learn more about our value-added features, and to catch the latest news!</p>
					<p><a href="https://www.facebook.com/" target="_blank"><img src="images/facebook.gif" alt="Facebook"></a> <a href="https://www.twitter.com/" target="_blank"><img src="images/twitter.gif" alt="Twitter"></a> <a href="https://www.linkedin.com/groups/" target="_blank"><img src="images/in.gif" alt="Linkedin"></a> <a href="http://www.youtube.com/" target="_blank"><img src="images/you.gif" alt="Youtube"></a></p>
				</div>
                                -->
			</div>
		</div>