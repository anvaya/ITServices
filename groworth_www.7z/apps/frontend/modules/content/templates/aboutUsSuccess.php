<div id="content" class="col-full">
			<div id="main-sidebar-container">
				<div id="main">
					<div class="post-144 page type-page status-publish hentry">
						<h2 class="title">About Groworth Real Solutions Pvt. Ltd.</h2>						
						<div class="entry">
							<h5>Who we are</h5>
                                                        
                                                        <p>Groworth Real Solutions Pvt. Ltd. has contributed immensely in the real estate and construction industry at 

Pune and Nagpur. We majorly cater to the investment needs of the NRIs based in Gulf, UK and USA. Our 
main aim is to provide our NRI clients appreciating investment opportunities so that they can reap rich
rewards from these investments.</p>

                                                        
<p>Starting with plots, Groworth slowly shifted to building and construction field and as of now has more 

than 21 clear titled real estate and construction projects under its name. Transparency and efficiency 

are the two virtues that have helped Groworth establish formidable trust and goodwill. Apart from 

establishing its impact In UAE, Qatar, Oman and Bahrain the company also has made a mark in other 

parts of the globe including UK and USA.</p>

<p>Over the years, Groworth has been successful in establishing good associations with its global clients 

and now has an investor friendly office placed in the Hamriyah free zone, UAE. The company has 

always yearned to provide good value commercial as well as residential projects to its customers based 

worldwide.</p>
							
						</div>

						<div class="entry">
							<h5>Diversifying for the better</h5>
							<p>
								Groworth has always been known to trace the pulse of its clients and have provided them with investment opportunities of their interest and expectations. The company has been seeking for diversifying options for some time now and has always kept the interest of its clients as priority. Years of contact with our NRI clients have enlightened us about the taxation problems they face when they come back to India. 
							</p>
							<p>
								That is why; Groworth has decided to venture into multiple servicing fields especially catering towards the requirements of our NRI clients. As of now, we are gearing up to introduce our work extension in three different areas including NRI Tax Services, Tours and Travel and property management of which department of NRI tax services have already started and the other two services will commence soon.
							</p>
						</div>

					</div>
				</div>
			</div>
		</div>