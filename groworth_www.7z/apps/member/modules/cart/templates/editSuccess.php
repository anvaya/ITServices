<h1>Edit Cart</h1>

<?php include_partial('form', array('form' => $form)) ?>
