<h1>New Cart</h1>

<?php include_partial('form', array('form' => $form)) ?>
