Dear <?php echo $sf_guard_user->getFirstName() ?>,
<br/><br/>
<h2 class="title"><?php echo __('Thank you !', null, 'messages') ?></h2><br />
<br />
<div class="entry">
  <p>Your Payment confirmation has been submitted successfully to our processing desk.</p>
  <p>Our representative will contact you shortly.</p> 
  <p>Please contact us in case you have any queries or feedback.</p>
</div>
