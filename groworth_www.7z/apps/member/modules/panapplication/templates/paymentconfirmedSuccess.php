<?php /*
<div id="main_content" style="width: 960px;">   
  <div id="content" class="col-full">
    <div id="main-sidebar-container">
      <div id="main">
        <div class="post-144 page type-page status-publish hentry">
          <h2 class="title"><?php echo __('Thank you !', null, 'messages') ?></h2>						                
          <br />
          <div class="entry">
            <?php if ($sf_user->hasFlash('notice')): ?>
              <div class="notice"><?php echo __($sf_user->getFlash('notice'), array(), 'sf_admin') ?></div>
            <?php endif; ?>
            <p>Your Payment confirmation has been submitted successfully to our processing desk.</p>
            <p>Our representative will contact you shortly.</p> 
            <p>Please <a href="/contactus.html">contact us</a> in case you have any queries or feedback.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 * 
 */ ?>