<div class="sf_admin_form_row sf_admin_text sf_admin_form_field_ticket_subject">
      <div>
        <label for="support_ticket_comments_0_public_message">Your Query</label>
        <div class="content">
            <?php echo $form['comments'][0]['public_message']->render(array("rows"=>10,"cols"=>60));?>
        </div>
      </div>
  </div>