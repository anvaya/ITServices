 <!-- Page Footer Start -->
    <div id="page_footer">
      <div id="page_footer_left"><p>Copyright &copy;&nbsp;<?php echo date('Y');?> Company name</p></div>
      <div id="page_footer_right"><p><?php /* echo link_to("Terms &amp; Conditions","@content?slug=terms-and-conditions",array("popup"=>array("Terms_n_Conditions","width=600,height=600,scrollbars=1") )) ?>   &nbsp; | &nbsp; <?php echo link_to("Privacy","@content?slug=privacy-policy",array("popup"=>array("Privacy_Policy","width=600,height=600,scrollbars=1") )) ?> &nbsp; | &nbsp; <?php echo link_to("Contact","@content?slug=contact-us",array("popup"=>array("ContactUs","width=600,height=600,scrollbars=1") )) */ ?></p>
      </div>
    </div>
  <!-- Page Footer End -->