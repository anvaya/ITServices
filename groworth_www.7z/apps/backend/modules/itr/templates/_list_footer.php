<script type="text/javascript">
jQuery(document).ready(function(){
  jQuery(".sf_admin_action_show").show();
  
});
</script>