<?php

/**
 * faq module helper.
 *
 * @package    DemegaDropShip
 * @subpackage faq
 * @author     Mrugendra Bhure
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class faqGeneratorHelper extends BaseFaqGeneratorHelper
{
}
