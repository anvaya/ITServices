<?php

/**
 * payment module helper.
 *
 * @package    BestBuddies
 * @subpackage payment
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class paymentGeneratorHelper extends BasePaymentGeneratorHelper
{
}
