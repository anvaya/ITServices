<script type="text/javascript">
    window.opener.location.href = window.opener.location.href;
    self.close();
</script>