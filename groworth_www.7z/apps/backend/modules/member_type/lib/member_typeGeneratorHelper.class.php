<?php

/**
 * member_type module helper.
 *
 * @package    BestBuddies
 * @subpackage member_type
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class member_typeGeneratorHelper extends BaseMember_typeGeneratorHelper
{
}
