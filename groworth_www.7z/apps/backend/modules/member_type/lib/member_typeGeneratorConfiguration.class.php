<?php

/**
 * member_type module configuration.
 *
 * @package    BestBuddies
 * @subpackage member_type
 * @author     Anvaya Technologies
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class member_typeGeneratorConfiguration extends BaseMember_typeGeneratorConfiguration
{
}
