<?php

require_once dirname(__FILE__).'/../lib/member_typeGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/member_typeGeneratorHelper.class.php';

/**
 * member_type actions.
 *
 * @package    BestBuddies
 * @subpackage member_type
 * @author     Anvaya Technologies
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class member_typeActions extends autoMember_typeActions
{
}
