<?php

/**
 * ticket module helper.
 *
 * @package    SupportDB
 * @subpackage ticket
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ticketGeneratorHelper extends BaseTicketGeneratorHelper
{
}
