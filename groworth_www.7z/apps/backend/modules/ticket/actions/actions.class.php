<?php

require_once dirname(__FILE__).'/../lib/ticketGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/ticketGeneratorHelper.class.php';

/**
 * ticket actions.
 *
 * @package    SupportDB
 * @subpackage ticket
 * @author     Anvaya Technologies
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ticketActions extends autoTicketActions
{
}
