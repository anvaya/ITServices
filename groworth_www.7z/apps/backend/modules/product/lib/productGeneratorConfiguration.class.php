<?php

/**
 * product module configuration.
 *
 * @package    BestBuddies
 * @subpackage product
 * @author     Anvaya Technologies
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class productGeneratorConfiguration extends BaseProductGeneratorConfiguration
{
}
