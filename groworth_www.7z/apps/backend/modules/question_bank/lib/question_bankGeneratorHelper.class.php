<?php

/**
 * question_bank module helper.
 *
 * @package    BestBuddies
 * @subpackage question_bank
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class question_bankGeneratorHelper extends BaseQuestion_bankGeneratorHelper
{
}
