<?php

require_once dirname(__FILE__).'/../lib/memberGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/memberGeneratorHelper.class.php';

/**
 * member actions.
 *
 * @package    BestBuddies
 * @subpackage member
 * @author     Anvaya Technologies
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class memberActions extends autoMemberActions
{
  public function executeShow(sfWebRequest $request)
  {
    $this->member = $this->getRoute()->getObject();
  }
  
  public function executeActivate(sfWebRequest $request)
  {
      $member = $this->getRoute()->getObject();
      
      $subscription = member_subscriptionTable::getInstance() 
                        ->createQuery('ms')
                        ->addWhere('ms.member_id = ?', $member->getId())
                        ->orderBy('ms.id desc')
                        ->fetchOne();
      
      if($subscription)
      {
          $member->setIsActive(1);
          $member->save();
          
          $subscription->setActive(1);
          $subscription->save();
          
          $this->getUser()->setFlash('notice','The account has been activated');
          $email_body = $this->getPartial("email_activation", array("user"=>$member, "subscription"=>$subscription));
          
          try
          {
            $msg = $this->getMailer()->compose();
            $msg->setSubject("You Groworth.in account is now active");
            $msg->addFrom("nriservices@groworth.in","Groworth Real Solutions Pvt. Ltd");
            $msg->addReplyTo("nrihelp@groworth.in", "Groworth Real Solutions Pvt. Ltd");
            $msg->addTo($member->getEmailAddress() , $member->getFirstName() );            
            $msg->setBody($email_body, 'text/html', "utf-8");
            $this->getMailer()->sendNextImmediately();
            $this->getMailer()->send($msg);
              
            $msg = $this->getMailer()->compose();
            $msg->setSubject("You Groworth.in account is now active");
            $msg->addFrom("nriservices@groworth.in","Groworth Real Solutions Pvt. Ltd");
            $msg->addReplyTo("nrihelp@groworth.in", "Groworth Real Solutions Pvt. Ltd");
            $msg->addTo("sandeep.groworth@gmail.com","Sandeep Ghadge");    
            $msg->addTo("mrugendrabhure@gmail.com","Mrugendra Bhure" );            
            $msg->setBody($email_body, 'text/html', "utf-8");
            $this->getMailer()->sendNextImmediately();
            $this->getMailer()->send($msg);
            
          }catch (Exception $ex) 
          {

          }
      }
      
      $this->redirect(array('sf_route' => 'member_edit', 'sf_subject' => $member));
  }
}
