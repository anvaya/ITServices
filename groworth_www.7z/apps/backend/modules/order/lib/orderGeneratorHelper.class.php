<?php

/**
 * order module helper.
 *
 * @package    BestBuddies
 * @subpackage order
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class orderGeneratorHelper extends BaseOrderGeneratorHelper
{
}
