<?php

/**
 * form_question module helper.
 *
 * @package    BestBuddies
 * @subpackage form_question
 * @author     Anvaya Technologies
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class form_questionGeneratorHelper extends BaseForm_questionGeneratorHelper
{
}
