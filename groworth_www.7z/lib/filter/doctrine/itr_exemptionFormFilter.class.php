<?php

/**
 * itr_exemption filter form.
 *
 * @package    BestBuddies
 * @subpackage filter
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class itr_exemptionFormFilter extends Baseitr_exemptionFormFilter
{
  public function configure()
  {
  }
}
