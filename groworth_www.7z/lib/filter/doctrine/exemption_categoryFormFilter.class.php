<?php

/**
 * exemption_category filter form.
 *
 * @package    BestBuddies
 * @subpackage filter
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class exemption_categoryFormFilter extends Baseexemption_categoryFormFilter
{
  /**
   * @see type_infoFormFilter
   */
  public function configure()
  {
    parent::configure();
  }
}
