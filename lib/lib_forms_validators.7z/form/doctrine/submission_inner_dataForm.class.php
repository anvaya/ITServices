<?php

/**
 * submission_inner_data form.
 *
 * @package    BestBuddies
 * @subpackage form
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class submission_inner_dataForm extends Basesubmission_inner_dataForm
{
  public function configure()
  {
  }
}
