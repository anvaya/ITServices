<?php

/**
 * subscription_product form.
 *
 * @package    BestBuddies
 * @subpackage form
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class subscription_productForm extends Basesubscription_productForm
{
  public function configure()
  {
  }
}
