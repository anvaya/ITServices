<?php

/**
 * cart_items form.
 *
 * @package    BestBuddies
 * @subpackage form
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class cart_itemsForm extends Basecart_itemsForm
{
  public function configure()
  {
  }
}
