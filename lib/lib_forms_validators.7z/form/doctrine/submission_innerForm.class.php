<?php

/**
 * submission_inner form.
 *
 * @package    BestBuddies
 * @subpackage form
 * @author     Anvaya Technologies
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class submission_innerForm extends Basesubmission_innerForm
{
  public function configure()
  {
  }
}
