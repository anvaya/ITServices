<?php
/**
 * Description of itrPropertyFormValidatorSchema
 *
 * @author Mrugendra Bhure
 */
class itrPropertyFormValidatorSchema extends sfValidatorSchema
{
    static $check_field = "details";
    
    protected function doClean($values)
    {
        $errorSchema = new sfValidatorErrorSchema($this);                               
         
        if(isset($values['owners']))
        {
            $values['owners'] = json_encode($values['owners']);            
        }
        
        if(isset($values['prev_year_receipt']))
        {
            $values['prev_year_receipt'] = json_encode($values['prev_year_receipt']);
        }
        else
        {
            $values['prev_year_receipt'] = json_encode(array());
        }
        return $values;
    }    
}

?>