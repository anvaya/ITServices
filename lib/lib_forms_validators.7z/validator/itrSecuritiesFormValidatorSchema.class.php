<?php
/**
 * Description of itrSecuritiesFormValidatorSchema.class.php
 *
 * @author Mrugendra Bhure
 */
class itrSecuritiesFormValidatorSchema extends sfValidatorSchema
{        
    const check_field = 'purchase_info';
    
    protected function doClean($values)
    {
        $errorSchema = new sfValidatorErrorSchema($this);                               
                
        if(isset($values[self::check_field]))
        {
            $values[self::check_field] = json_encode($values[self::check_field]);
        }
        else
        {
            $values[self::check_field] = json_encode(array());
        }
        return $values;
    }    
}

?>